#ifndef SYMBOLS_H
#define SYMBOLS_H
#include <inttypes.h>
#include <stdio.h>

/**
 * Symbols
 */
struct _Symbols{

	char* symbol;
	int off;
};

typedef struct _Symbols Symbol;

#endif
